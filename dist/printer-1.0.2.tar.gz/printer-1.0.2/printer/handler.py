def my_print():
    print("Print Here")