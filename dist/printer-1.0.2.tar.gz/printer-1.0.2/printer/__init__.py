from printer.handler import my_print
from printer.other.main import another_print
__all__ = ['my_print','another_print']