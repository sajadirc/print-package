# from setuptools import setup
from setuptools import setup
# setup(name= 'printer', version= '1.0.1', description='this Module print same text')
setup(
    name="printer",
    version="1.0.2",
    description="this Module print same text",
    url="https://github.com/sajadirc/print-package.git",
)
