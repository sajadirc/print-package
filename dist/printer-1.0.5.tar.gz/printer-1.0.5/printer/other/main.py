def another_print():
    print('another print')