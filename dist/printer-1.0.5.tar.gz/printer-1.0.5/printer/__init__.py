from printer.handler import my_print
from printer.other.main import another_print
from printer.handler import print_rates
__all__ = ['my_print','another_print','print_rates']