from printer.handler import my_print

__all__ = ['my_print']